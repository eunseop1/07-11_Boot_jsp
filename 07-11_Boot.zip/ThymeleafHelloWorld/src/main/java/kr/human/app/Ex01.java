package kr.human.app;

public class Ex01 {
	public static void main(String[] args) {
		int a = 2;
		System.out.println(a);
		a = a * a;
		System.out.println(a);
		a = a * a;
		System.out.println(a);
	}
}
