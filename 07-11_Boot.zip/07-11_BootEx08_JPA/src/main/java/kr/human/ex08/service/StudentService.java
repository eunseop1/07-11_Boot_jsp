package kr.human.ex08.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.human.ex08.dao.StudentDAO;
import kr.human.ex08.vo.Student;

@Service
public class StudentService {
	
	@Autowired
	private StudentDAO studentDAO;
	
	public List<Student> selectAll(){//모두 얻기
		List<Student> list = new ArrayList<>();
		studentDAO.findAll().forEach(list::add);
		return list;
	}
	
	public Optional<Student> selectById(int id) {//한개 얻기
		return studentDAO.findById(id);
	}
	
	public Student insert(Student student) {//저장하기
		return studentDAO.save(student);//save는 student, 즉 저장된 객체를 리턴
	}
	
	public Student update(Student student) {//수정하기
		Optional<Student> vo = studentDAO.findById(student.getId());
		if(!vo.isPresent()) {//vo가 존재하지 않는다면
			return null;
		}
		Student student2 = vo.get();
		student2.setFirstName(student.getFirstName());
		student2.setLastName(student.getLastName());
		student2.setSection(student.getSection());
		
		return studentDAO.save(student2);
	}
	
	public Student delete(Student student) {//삭제하기
		Optional<Student> vo = studentDAO.findById(student.getId());
		if(!vo.isPresent()) {
			return null;
		}
		Student student2 = vo.get();
		studentDAO.delete(student2);
		return student2;
	}
}