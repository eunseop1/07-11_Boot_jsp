package kr.human.ex06.dao;

import java.util.Date;

public interface TestDAO {
	String selectNow();
	Date selectToday();
}
