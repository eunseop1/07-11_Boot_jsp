package kr.human.ex01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import kr.human.ex01.vo.TestVO;
import lombok.RequiredArgsConstructor;

@SpringBootApplication
@RestController // 이 클래스를 REST 컨트롤러로 사용하겠다 -> VO와 DAO부르는 작업을 대신 해준다
public class BootEx01HelloWorldApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootEx01HelloWorldApplication.class, args);
	}
	
	// Get방식으로 /에 접속하는 주소를 하나 생성했다
	@GetMapping(value = "/") //여러개를 주소로 연결하려면 배열로 한다
	public String hello() {
		return "Hello Spring Boot!!!";
	}
	
	@RequestMapping(value = {"/hi","/hello"}) // 하나의 메서드로 주소 여러개 지정가능(Get/Post 모두 가능)
	// 주소줄 뒤에 ?name = @@을 적지 않으면 작동이 안된다. 이를 해결하기 위해서는
	//@RequestParam(required = false)로 인수 받는게 필수가 아니게 설정하면 된다
	public String hello2(@RequestParam(required = false) String name) {
		if(name == null || name.trim().length() == 0) name = "손";
		return name + "님 반갑습니다.";
	}
	
	@RequestMapping(value = "vo") //주소줄에 vo를 치면 json으로 출력된다
	public TestVO testVO() {
		return new TestVO("한사람", 22, false);
	}


}
